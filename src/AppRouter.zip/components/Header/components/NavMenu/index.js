import React from 'react';

class NavMenu extends React.Component {
    render() {
        return (
            <div>

            </div>
        );
    }
}

export default NavMenu;